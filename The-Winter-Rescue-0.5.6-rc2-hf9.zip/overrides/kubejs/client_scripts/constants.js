const clientItemsToHide = [
];

const fluidsToHide = [

];

const regexHide = [

];

const serverItemsToHide = [
    'minecraft:blast_furnace',
    'minecraft:furnace',
	'minecraft:diamond_pickaxe',

    // ie
    'immersiveengineering:toolbox',
    'immersiveengineering:sorter',
    'immersiveengineering:fluid_sorter',
    'immersiveengineering:watermill',
    'immersiveengineering:windmill',
	'engineersdecor:metal_crafting_table',

    // rankine items
    'rankine:element_transmuter',
    'rankine:up_transmuter',
    'rankine:down_transmuter',
    'rankine:left_transmuter',
    'rankine:right_transmuter',
    'rankine:totem_of_cobbling',
    'rankine:thermometer',
    'rankine:alloy_plate',
    'rankine:alloy_ingot',
    'rankine:alloy_gear',
    'rankine:totem_of_cobbling',
    'rankine:element_indexer',
    'rankine:power_cell',
    'rankine:power_cell_2',
    'rankine:power_cell_3',
    'rankine:power_cell_4',
    'rankine:power_cell_5',
    'rankine:power_cell_6',
    'rankine:steel_gold_pan',

    // create power devices: we have steam power
    'create:water_wheel',
    'create:cogwheel',
    'create:large_cogwheel',
    'create:windmill_bearing',
    'create:flywheel',
    'create:furnace_engine',

    'create:mechanical_piston',
    'create:sticky_mechanical_piston',
    'create:piston_extension_pole',
    'create:cart_assembler',

    // rankine machines
    'rankine:diamond_anvil_cell',
    'rankine:rankine_box',
    'rankine:sediment_fan',
    'rankine:rare_earth_electromagnet',
    'rankine:alnico_electromagnet',
    'rankine:charcoal_pit'
];

const recipesToHide = [

];