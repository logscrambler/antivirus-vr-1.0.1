onEvent('jei.add.items', (event) => {
    // const items = [
    //
    // ];
    //
    // items.forEach((item) => event.add(item));
});
