script priority convention:

put
//priority: number
on top of scripts

tags: 2000
functions, loot_tables: 1000
remove: 100
other recipes: 99
other events (player logged in, advancements, etc): 1
unify outputs: 0

Test

Test2